"""
Competition models for the CV Benchmark Platform.

This module defines the core data models:
- Competition: The main competition entity
- CompetitionParticipant: Whitelist with per-user time windows
- Submission: Prediction file uploads and scores
- SubmissionLog: Detailed scoring logs for debugging
"""

from django.conf import settings
from django.db import models
from django.utils import timezone
from typing import Any


class TaskType(models.TextChoices):
    """Supported CV task types."""
    CLASSIFICATION = 'CLASSIFICATION', 'Image Classification'
    DETECTION = 'DETECTION', 'Object Detection'
    SEGMENTATION = 'SEGMENTATION', 'Image Segmentation'
    CUSTOM = 'CUSTOM', 'Custom Script'


class MetricType(models.TextChoices):
    """Supported evaluation metrics."""
    ACCURACY = 'ACCURACY', 'Accuracy'
    
    # F1 variants
    F1 = 'F1', 'F1-Score (Macro)'
    F1_MACRO = 'F1_MACRO', 'F1-Score (Macro)'
    F1_MICRO = 'F1_MICRO', 'F1-Score (Micro / Accuracy)'
    F1_WEIGHTED = 'F1_WEIGHTED', 'F1-Score (Weighted)'
    
    # Precision variants
    PRECISION = 'PRECISION', 'Precision (Macro)'
    PRECISION_MACRO = 'PRECISION_MACRO', 'Precision (Macro)'
    PRECISION_MICRO = 'PRECISION_MICRO', 'Precision (Micro)'
    PRECISION_WEIGHTED = 'PRECISION_WEIGHTED', 'Precision (Weighted)'
    
    # Recall variants
    RECALL = 'RECALL', 'Recall (Macro)'
    RECALL_MACRO = 'RECALL_MACRO', 'Recall (Macro)'
    RECALL_MICRO = 'RECALL_MICRO', 'Recall (Micro)'
    RECALL_WEIGHTED = 'RECALL_WEIGHTED', 'Recall (Weighted)'
    
    # Per-class variants
    CLASS_F1 = 'CLASS_F1', 'F1-Score (Class-Specific)'
    CLASS_PRECISION = 'CLASS_PRECISION', 'Precision (Class-Specific)'
    CLASS_RECALL = 'CLASS_RECALL', 'Recall (Class-Specific)'

    MAP = 'MAP', 'mAP@0.5'
    MAP_50_95 = 'MAP_50_95', 'mAP@[0.5:0.95]'
    MIOU = 'MIOU', 'mIoU'


class CompetitionStatus(models.TextChoices):
    """Competition lifecycle status."""
    DRAFT = 'DRAFT', 'Draft'
    ACTIVE = 'ACTIVE', 'Active'
    ENDED = 'ENDED', 'Ended'


class SubmissionStatus(models.TextChoices):
    """Submission processing status."""
    PENDING = 'PENDING', 'Pending'
    PROCESSING = 'PROCESSING', 'Processing'
    SUCCESS = 'SUCCESS', 'Success'
    FAILED = 'FAILED', 'Failed'


class LogLevel(models.TextChoices):
    """Log severity levels."""
    INFO = 'INFO', 'Info'
    WARNING = 'WARNING', 'Warning'
    ERROR = 'ERROR', 'Error'


def competition_ground_truth_path(instance: Any, filename: str) -> str:
    """Generate upload path for ground truth files."""
    return f'competitions/{instance.id}/ground_truth/{filename}'


def submission_prediction_path(instance: Any, filename: str) -> str:
    """Generate upload path for prediction files."""
    return f'submissions/{instance.competition_id}/{instance.user_id}/{filename}'


def competition_scoring_script_path(instance: Any, filename: str) -> str:
    """Generate upload path for scoring scripts."""
    return f'competitions/{instance.id}/scripts/{filename}'


class Competition(models.Model):
    """
    A CV competition created by an admin.
    
    Stores competition metadata, ground truth files, and upload limits.
    """
    name = models.CharField(
        max_length=100,
        verbose_name='Competition Name',
        help_text='e.g., Defect Detection Challenge'
    )
    description = models.TextField(
        verbose_name='Description',
        help_text='Markdown supported',
        blank=True
    )
    task_type = models.CharField(
        max_length=20,
        choices=TaskType.choices,
        verbose_name='Task Type'
    )
    metric_type = models.CharField(
        max_length=20,
        choices=MetricType.choices,
        verbose_name='Metric'
    )
    
    # Ground truth files
    public_ground_truth = models.FileField(
        upload_to=competition_ground_truth_path,
        verbose_name='Public Ground Truth',
        help_text='CSV format'
    )
    private_ground_truth = models.FileField(
        upload_to=competition_ground_truth_path,
        verbose_name='Private Ground Truth',
        help_text='CSV format, only visible to Validators',
        blank=True,
        null=True
    )
    
    scoring_script = models.FileField(
        upload_to=competition_scoring_script_path,
        verbose_name='Scoring Script',
        help_text='Python script for custom scoring. Must implement calculate_score().',
        blank=True,
        null=True
    )
    
    # Dataset access
    dataset_url = models.URLField(
        verbose_name='Dataset Download URL',
        blank=True
    )
    
    # Upload limits
    daily_upload_limit = models.PositiveIntegerField(
        default=5,
        verbose_name='Daily Upload Limit'
    )
    total_upload_limit = models.PositiveIntegerField(
        default=100,
        verbose_name='Total Upload Limit'
    )
    
    # Status
    status = models.CharField(
        max_length=20,
        choices=CompetitionStatus.choices,
        default=CompetitionStatus.DRAFT,
        verbose_name='Status'
    )

    metric_target_class = models.CharField(
        max_length=100,
        blank=True,
        verbose_name='Metric Target Class',
        help_text='Required if selecting a Class-Specific metric'
    )

    available_metrics = models.JSONField(
        default=list,
        verbose_name='Available Metrics',
        help_text='Select all metrics to be displayed on the leaderboard',
        blank=True
    )
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Created At')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='Updated At')

    class Meta:
        verbose_name = 'Competition'
        verbose_name_plural = 'Competitions'
        ordering = ['-created_at']

    def __str__(self) -> str:
        return self.name


class CompetitionParticipant(models.Model):
    """
    Whitelist entry linking a user to a competition with a time window.
    
    Each participant has their own start/end time, allowing staggered
    competition access for different team members.
    """
    competition = models.ForeignKey(
        Competition,
        on_delete=models.CASCADE,
        related_name='participants',
        verbose_name='Competition'
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='competition_participations',
        verbose_name='Participant'
    )
    
    # Per-user time window
    start_time = models.DateTimeField(verbose_name='Start Time')
    end_time = models.DateTimeField(verbose_name='End Time')
    
    # Manual control
    is_active = models.BooleanField(
        default=True,
        verbose_name='Active',
        help_text='Uncheck to suspend participation'
    )
    
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Created At')

    class Meta:
        verbose_name = 'Competition Participant'
        verbose_name_plural = 'Competition Participants'
        unique_together = ['competition', 'user']
        indexes = [
            models.Index(fields=['competition', 'user']),
            models.Index(fields=['start_time', 'end_time']),
        ]

    def __str__(self):
        return f'{self.user} @ {self.competition}'

    def is_within_time_window(self) -> bool:
        """Check if current time is within the participation window."""
        now = timezone.now()
        return self.start_time <= now <= self.end_time

    def can_participate(self) -> bool:
        """Check if user can currently participate (active + within time)."""
        return self.is_active and self.is_within_time_window()


class Submission(models.Model):
    """
    A prediction file submission from a participant.
    
    Tracks the upload, scoring status, and both public/private scores.
    """
    competition = models.ForeignKey(
        Competition,
        on_delete=models.CASCADE,
        related_name='submissions',
        verbose_name='Competition'
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='submissions',
        verbose_name='Submitter'
    )
    
    # Uploaded file
    prediction_file = models.FileField(
        upload_to=submission_prediction_path,
        verbose_name='Prediction File'
    )
    
    # Processing status
    status = models.CharField(
        max_length=20,
        choices=SubmissionStatus.choices,
        default=SubmissionStatus.PENDING,
        verbose_name='Status'
    )
    
    # Scores
    public_score = models.FloatField(
        null=True,
        blank=True,
        verbose_name='Public Score'
    )
    private_score = models.FloatField(
        null=True,
        blank=True,
        verbose_name='Private Score',
        help_text='Filled by Validator'
    )
    
    # Final selection flag
    is_final_selection = models.BooleanField(
        default=False,
        verbose_name='Final Selection',
        help_text='Mark this as the final version for scoring'
    )
    
    # Error handling
    error_message = models.TextField(
        blank=True,
        verbose_name='Error Message'
    )

    all_scores = models.JSONField(
        null=True,
        blank=True,
        verbose_name='All Scores',
        help_text='JSON containing all calculated metrics'
    )
    
    # Timestamps
    submitted_at = models.DateTimeField(auto_now_add=True, verbose_name='Submitted At')
    scored_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='Scored At'
    )

    class Meta:
        verbose_name = 'Submission'
        verbose_name_plural = 'Submissions'
        ordering = ['-submitted_at']
        indexes = [
            models.Index(fields=['competition', 'user', '-submitted_at']),
            models.Index(fields=['competition', 'is_final_selection']),
            models.Index(fields=['status']),
        ]

    def __str__(self) -> str:
        return f'Submission #{self.id} by {self.user}'

    @classmethod
    def get_today_count(cls, competition: Any, user: Any) -> int:
        """Get number of submissions by this user today."""
        today = timezone.now().date()
        return cls.objects.filter(
            competition=competition,
            user=user,
            submitted_at__date=today
        ).count()

    @classmethod
    def get_total_count(cls, competition: Any, user: Any) -> int:
        """Get total number of submissions by this user."""
        return cls.objects.filter(
            competition=competition,
            user=user
        ).count()

    def can_submit_more_today(self) -> bool:
        """Check if user hasn't exceeded daily limit."""
        today_count = self.get_today_count(self.competition, self.user)
        return today_count < self.competition.daily_upload_limit

    def can_submit_more_total(self) -> bool:
        """Check if user hasn't exceeded total limit."""
        total_count = self.get_total_count(self.competition, self.user)
        return total_count < self.competition.total_upload_limit


class SubmissionLog(models.Model):
    """
    Detailed log entries for a submission's scoring process.
    
    Useful for debugging scoring failures and tracking progress.
    """
    submission = models.ForeignKey(
        Submission,
        on_delete=models.CASCADE,
        related_name='logs',
        verbose_name='Submission'
    )
    level = models.CharField(
        max_length=10,
        choices=LogLevel.choices,
        default=LogLevel.INFO,
        verbose_name='Level'
    )
    message = models.TextField(verbose_name='Message')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Created At')

    class Meta:
        verbose_name = 'Scoring Log'
        verbose_name_plural = 'Scoring Logs'
        ordering = ['created_at']

    def __str__(self) -> str:
        return f'[{self.level}] {self.message[:50]}'


class RegistrationWhitelist(models.Model):
    """
    Whitelist of usernames allowed to register on the platform.
    """
    username = models.CharField(
        max_length=150,
        unique=True,
        verbose_name='Whitelisted Username'
    )
    notes = models.TextField(
        blank=True,
        help_text='Optional notes (e.g., real name)'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Registration Whitelist'
        verbose_name_plural = 'Registration Whitelists'

    def __str__(self) -> str:
        return self.username
