from django.apps import AppConfig


class CompetitionsConfig(AppConfig):
    name = "competitions"
