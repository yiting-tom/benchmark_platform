
from scoring.engines.base import ScoringResult
import pandas as pd

REQUIRED_COLUMNS = ['filename', 'label']

def calculate_score(prediction_df, ground_truth_df):
    # Just return a hardcoded score and a log
    return ScoringResult(
        success=True,
        score=0.95,
        metrics={'custom_metric': 123},
        logs=['Log from custom script']
    )
