
def calculate_score(prediction_df, ground_truth_df):
    raise ValueError("Something went wrong in custom script")
