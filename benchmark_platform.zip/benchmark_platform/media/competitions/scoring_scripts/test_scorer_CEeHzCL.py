
import pandas as pd
def calculate_score(prediction_df, ground_truth_df, **kwargs):
    # Intentional specific logic for testing:
    # return the number of rows in prediction as the score
    return float(len(prediction_df))
