from django.apps import AppConfig


class ScoringConfig(AppConfig):
    name = "scoring"
