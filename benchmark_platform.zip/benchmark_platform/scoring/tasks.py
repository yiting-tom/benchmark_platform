from django.utils import timezone

from competitions.models import (
    Competition,
    Submission,
    SubmissionLog,
    SubmissionStatus,
    LogLevel,
    TaskType,
)
from .engines.classification import ClassificationScoringEngine
from .engines.detection import DetectionScoringEngine
from .engines.segmentation import SegmentationScoringEngine
from .engines.custom import CustomScoringEngine
from typing import Tuple


def get_scoring_engine(competition: Competition):
    """
    Factory function to get the appropriate scoring engine for a competition.
    
    Args:
        competition: The Competition instance.
        
    Returns:
        An initialized scoring engine.
        
    Raises:
        ValueError: If task type is not supported.
    """
    ground_truth_path = competition.public_ground_truth.path
    metric_type = competition.metric_type
    
    if competition.scoring_script:
        return CustomScoringEngine(ground_truth_path, competition.scoring_script.path)
    
    if competition.task_type == TaskType.CLASSIFICATION:
        return ClassificationScoringEngine(
            ground_truth_path, metric_type, competition.metric_target_class
        )
    elif competition.task_type == TaskType.DETECTION:
        return DetectionScoringEngine(ground_truth_path, metric_type)
    elif competition.task_type == TaskType.SEGMENTATION:
        return SegmentationScoringEngine(ground_truth_path, metric_type)
    elif competition.task_type == TaskType.CUSTOM:
        raise ValueError("Competition set to Custom Script but no script uploaded")
    else:
        raise ValueError(f"Unknown task type: {competition.task_type}")


def add_submission_log(submission: Submission, message: str, level: str = LogLevel.INFO) -> None:
    """Helper to add a log entry to a submission."""
    SubmissionLog.objects.create(
        submission=submission,
        level=level,
        message=message
    )


def parse_engine_log(log_msg: str) -> Tuple[str, str]:
    """Parse log level and message from engine log string."""
    if log_msg.startswith("[ERROR]"):
        return LogLevel.ERROR, log_msg.replace("[ERROR] ", "", 1)
    elif log_msg.startswith("[WARNING]"):
        return LogLevel.WARNING, log_msg.replace("[WARNING] ", "", 1)
    elif log_msg.startswith("[INFO]"):
        return LogLevel.INFO, log_msg.replace("[INFO] ", "", 1)
    else:
        return LogLevel.INFO, log_msg


def score_submission(submission_id: int) -> dict:
    """
    Score a single submission.
    
    This is the main task that gets queued by Django-Q2.
    
    Args:
        submission_id: ID of the Submission to score.
        
    Returns:
        Dict with scoring result summary.
    """
    try:
        submission = Submission.objects.select_related("competition").get(id=submission_id)
    except Submission.DoesNotExist:
        return {"success": False, "error": f"Submission {submission_id} not found"}
    
    # Update status to PROCESSING
    submission.status = SubmissionStatus.PROCESSING
    submission.save(update_fields=["status"])
    add_submission_log(submission, "Started scoring", LogLevel.INFO)
    
    try:
        # Get the appropriate scoring engine
        competition = submission.competition
        engine = get_scoring_engine(competition)
        
        # Run scoring
        prediction_path = submission.prediction_file.path
        result = engine.score(prediction_path)
        
        # Save logs from engine
        for log_msg in (result.logs or []):
            level, message = parse_engine_log(log_msg)
            add_submission_log(submission, message, level)
        
        if result.success:
            submission.status = SubmissionStatus.SUCCESS
            submission.public_score = result.score
            submission.all_scores = result.metrics
            submission.scored_at = timezone.now()
            submission.save(update_fields=["status", "public_score", "all_scores", "scored_at"])
            
            add_submission_log(
                submission, 
                f"Scoring completed. Score: {result.score}", 
                LogLevel.INFO
            )
            
            return {
                "success": True,
                "submission_id": submission_id,
                "score": result.score,
                "metrics": result.metrics,
            }
        else:
            submission.status = SubmissionStatus.FAILED
            submission.error_message = result.error_message or "Unknown error"
            submission.save(update_fields=["status", "error_message"])
            
            add_submission_log(
                submission,
                f"Scoring failed: {result.error_message}",
                LogLevel.ERROR
            )
            
            return {
                "success": False,
                "submission_id": submission_id,
                "error": result.error_message,
            }
            
    except NotImplementedError as e:
        submission.status = SubmissionStatus.FAILED
        submission.error_message = str(e)
        submission.save(update_fields=["status", "error_message"])
        add_submission_log(submission, str(e), LogLevel.ERROR)
        
        return {"success": False, "submission_id": submission_id, "error": str(e)}
        
    except Exception as e:
        submission.status = SubmissionStatus.FAILED
        submission.error_message = f"Unexpected error: {e}"
        submission.save(update_fields=["status", "error_message"])
        add_submission_log(submission, f"Unexpected error: {e}", LogLevel.ERROR)
        
        return {"success": False, "submission_id": submission_id, "error": str(e)}
