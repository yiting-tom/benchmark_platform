def main():
    print("Hello from benchmark-platform!")


if __name__ == "__main__":
    main()
